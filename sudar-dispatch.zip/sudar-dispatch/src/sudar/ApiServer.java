package sudar;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Small REST API (JDK built-in HTTP server, no extra libraries) so the web page
 * web/backend.html can use the Java engine and the MySQL data.
 *   GET  /api/state      whole data set + dispatch results
 *   POST /api/incident   {"type":"..","location":"ERD","severity":4,"needs":["FIRE"]}
 *   POST /api/road       {"from":"ERD","to":"CHD","blocked":true}
 */
public class ApiServer {
    private final AppState app; private final int port; private HttpServer server;
    public ApiServer(AppState app, int port) { this.app = app; this.port = port; }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.createContext("/api/state", ex -> handle(ex, () -> app.snapshot()));
        server.createContext("/api/incident", ex -> handle(ex, () -> {
            Map<String, Object> b = body(ex);
            Set<String> needs = new LinkedHashSet<>();
            for (Object n : (List<?>) b.getOrDefault("needs", Collections.emptyList())) needs.add(String.valueOf(n).toUpperCase());
            String loc = String.valueOf(b.get("location")); String type = String.valueOf(b.getOrDefault("type", "")).trim();
            if (type.isEmpty() || needs.isEmpty() || app.data().location(loc) == null) throw new IllegalArgumentException("type, location and needs are required");
            int sev = ((Number) b.getOrDefault("severity", 3.0)).intValue();
            if (sev < 1 || sev > 5) throw new IllegalArgumentException("severity must be 1-5");
            Incident inc = app.report(type, loc, sev, needs);
            String err = app.save();
            Map<String, Object> out = app.snapshot(); out.put("created", inc.getId()); if (err != null) out.put("warning", err);
            return out;
        }));
        server.createContext("/api/road", ex -> handle(ex, () -> {
            Map<String, Object> b = body(ex);
            if (!app.setRoad(String.valueOf(b.get("from")), String.valueOf(b.get("to")), Boolean.TRUE.equals(b.get("blocked"))))
                throw new IllegalArgumentException("unknown road");
            String err = app.save();
            Map<String, Object> out = app.snapshot(); if (err != null) out.put("warning", err);
            return out;
        }));
        server.start();
    }
    public void stop() { if (server != null) server.stop(0); }
    public int getPort() { return port; }

    private interface Action { Object run() throws Exception; }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> body(HttpExchange ex) throws IOException {
        byte[] raw = ex.getRequestBody().readAllBytes();
        return (Map<String, Object>) MiniJson.parse(new String(raw, StandardCharsets.UTF_8));
    }

    private void handle(HttpExchange ex, Action a) throws IOException {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
        if ("OPTIONS".equals(ex.getRequestMethod())) { ex.sendResponseHeaders(204, -1); ex.close(); return; }
        int code = 200; String json;
        try { json = MiniJson.write(a.run()); }
        catch (IllegalArgumentException | ClassCastException | NullPointerException e) { code = 400; json = MiniJson.write(Map.of("error", String.valueOf(e.getMessage()))); }
        catch (Exception e) { code = 500; json = MiniJson.write(Map.of("error", String.valueOf(e.getMessage()))); }
        byte[] out = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, out.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(out); }
    }
}
